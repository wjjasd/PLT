package com.mega.plt.quiz;


public interface QuizDetailInterface {
	void quizDetailInsert(QuizDetailVO quizDetailVO);
}
