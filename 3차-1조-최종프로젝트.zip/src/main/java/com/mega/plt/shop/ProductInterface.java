package com.mega.plt.shop;

public interface ProductInterface {
	void create(ProductVO vo);
}
