package com.mega.plt.shop;

public class PointVO {
	
	private String pntID;
	private String uID;
	private int score;
	private String cDate;
	
	public String getPntID() {
		return pntID;
	}
	public void setPntID(String pntID) {
		this.pntID = pntID;
	}
	public String getuID() {
		return uID;
	}
	public void setuID(String uID) {
		this.uID = uID;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getcDate() {
		return cDate;
	}
	public void setcDate(String cDate) {
		this.cDate = cDate;
	}
	
	
}