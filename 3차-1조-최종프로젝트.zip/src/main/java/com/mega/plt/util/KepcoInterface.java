package com.mega.plt.util;

public interface KepcoInterface {
	boolean isRealPole(String poleNum);
}