package com.mega.plt.user;

public interface UserInterface {
	int create(UserVO vo);
}
